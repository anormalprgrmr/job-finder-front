import { Component } from '@angular/core';

@Component({
  selector: 'app-add-job',
  standalone: true,
  imports: [],
  templateUrl: './add-job.component.html',
  styleUrl: './add-job.component.css'
})
export class AddJobComponent {

}
