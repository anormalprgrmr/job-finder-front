import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CompanyService {
  constructor(private http: HttpClient) {}
  BACK_URL = 'http://localhost:3100'
  addJobService(data:any){
    return this.http.post(`${this.BACK_URL}/company`,data)
  }

}
