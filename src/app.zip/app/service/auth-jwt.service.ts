import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthJWTService {
  private apiUrl = 'http://localhost:3100/verify-token';  // Your backend API URL

  constructor(private http: HttpClient) {}

  verifyToken(token: string): Observable<any> {

    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
    return this.http.get(`${this.apiUrl}/verify-token`)
  }
}
